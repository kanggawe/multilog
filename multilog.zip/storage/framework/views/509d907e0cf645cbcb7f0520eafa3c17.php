<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-7xl mx-auto">
        <h1 class="text-3xl font-bold text-gray-900 mb-6">Dashboard</h1>

        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="px-4 py-5 sm:p-6">
                <h2 class="text-xl font-semibold mb-4">Welcome, <?php echo e($user->name); ?>!</h2>
                
                <div class="mb-4">
                    <p class="text-gray-600"><strong>Email:</strong> <?php echo e($user->email); ?></p>
                    <p class="text-gray-600"><strong>Role:</strong> 
                        <span class="inline-block bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded">
                            <?php echo e($user->role->name ?? 'No Role'); ?>

                        </span>
                    </p>
                </div>

                <div class="mt-6">
                    <?php if($user->isSuperAdmin()): ?>
                        <div class="bg-purple-50 border-l-4 border-purple-400 p-4 mb-4">
                            <div class="flex">
                                <div class="ml-3">
                                    <p class="text-sm text-purple-700">
                                        <strong>Super Admin Access:</strong> You have full system privileges and control.
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php elseif($user->isAdmin()): ?>
                        <div class="bg-green-50 border-l-4 border-green-400 p-4 mb-4">
                            <div class="flex">
                                <div class="ml-3">
                                    <p class="text-sm text-green-700">
                                        <strong>Admin Access:</strong> You have full administrative privileges.
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php elseif($user->isManager()): ?>
                        <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
                            <div class="flex">
                                <div class="ml-3">
                                    <p class="text-sm text-yellow-700">
                                        <strong>Manager Access:</strong> You have limited administrative privileges.
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="bg-blue-50 border-l-4 border-blue-400 p-4 mb-4">
                            <div class="flex">
                                <div class="ml-3">
                                    <p class="text-sm text-blue-700">
                                        <strong>User Access:</strong> You have basic access to the system.
                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <h3 class="font-semibold mb-2">Quick Actions</h3>
                        <ul class="list-disc list-inside text-sm text-gray-600">
                            <?php if($user->isAdmin() || $user->isManager()): ?>
                                <li><a href="<?php echo e(route('admin.users.index')); ?>" class="text-blue-600 hover:underline">Manage Users</a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route('account.profile')); ?>" class="text-blue-600 hover:underline">View Profile</a></li>
                            <li><a href="<?php echo e(route('account.settings')); ?>" class="text-blue-600 hover:underline">Settings</a></li>
                        </ul>
                    </div>

                    <div class="bg-gray-50 p-4 rounded-lg">
                        <h3 class="font-semibold mb-2">Statistics</h3>
                        <ul class="text-sm text-gray-600">
                            <li>Total Users: <?php echo e(\App\Models\User::count()); ?></li>
                            <li>Your Role: <?php echo e($user->role->name ?? 'N/A'); ?></li>
                        </ul>
                    </div>

                    <div class="bg-gray-50 p-4 rounded-lg">
                        <h3 class="font-semibold mb-2">Account Info</h3>
                        <ul class="text-sm text-gray-600">
                            <li>Registered: <?php echo e($user->created_at->format('M d, Y')); ?></li>
                            <li>Last Login: Recently</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BIG\multilog\resources\views/dashboard.blade.php ENDPATH**/ ?>