<?php $__env->startSection('title', 'User Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="py-6">
    <div class="max-w-7xl mx-auto">
        <h1 class="text-3xl font-bold text-gray-900 mb-6">User Details</h1>

        <div class="bg-white shadow rounded-lg p-6">
            <div class="mb-6">
                <div class="flex items-center mb-4">
                    <div class="h-16 w-16 rounded-full bg-gray-300 flex items-center justify-center mr-4">
                        <span class="text-gray-600 font-semibold text-2xl"><?php echo e(substr($user->name, 0, 1)); ?></span>
                    </div>
                    <div>
                        <h2 class="text-2xl font-bold text-gray-900"><?php echo e($user->name); ?></h2>
                        <p class="text-gray-600"><?php echo e($user->email); ?></p>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Name</label>
                    <p class="text-gray-900"><?php echo e($user->name); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <p class="text-gray-900"><?php echo e($user->email); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Role</label>
                    <span class="inline-block px-2 py-1 text-xs font-semibold rounded-full 
                        <?php if($user->role && $user->role->name === 'admin'): ?> bg-red-100 text-red-800
                        <?php elseif($user->role && $user->role->name === 'manager'): ?> bg-yellow-100 text-yellow-800
                        <?php else: ?> bg-green-100 text-green-800
                        <?php endif; ?>">
                        <?php echo e($user->role->name ?? 'No Role'); ?>

                    </span>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Registered</label>
                    <p class="text-gray-900"><?php echo e($user->created_at->format('F d, Y H:i')); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Last Updated</label>
                    <p class="text-gray-900"><?php echo e($user->updated_at->format('F d, Y H:i')); ?></p>
                </div>
            </div>

            <div class="flex items-center justify-between pt-4 border-t">
                <a href="<?php echo e(route('admin.users.index')); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                    Back to List
                </a>
                <?php if(auth()->user()->isAdmin()): ?>
                    <div class="space-x-2">
                        <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            Edit
                        </a>
                        <form method="POST" action="<?php echo e(route('admin.users.destroy', $user)); ?>" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded" onclick="return confirm('Are you sure you want to delete this user?')">
                                Delete
                            </button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BIG\multilog\resources\views/admin/users/show.blade.php ENDPATH**/ ?>