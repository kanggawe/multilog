# Laravel Multi-Level User System
Sistem manajemen pengguna multi-level dengan role dan permission untuk Laravel.
## 🚀 Fitur
- ✅ Sistem Authentication (Login/Logout)
- ✅ Multi-Level User dengan Role (Admin, Manager, User)
- ✅ Middleware untuk Role Checking
- ✅ CRUD User Management untuk Admin
- ✅ Dashboard berdasarkan Role
- ✅ UI Modern dengan Tailwind CSS v4
- ✅ Responsive Design
- ✅ Form Validation
- ✅ Flash Messages
## 👥 Struktur Role
1. **Admin** - Akses penuh, dapat mengelola semua user dan sistem
2. **Manager** - Akses terbatas, dapat melihat dan mengelola user
3. **User** - Akses dasar, hanya dapat melihat dashboard personal
## 📦 Instalasi
1. Clone repository ini:
   ```bash
   git clone https://github.com/kanggawe/multilog.git
   cd multilog
   ```
2. Install dependencies:
   ```bash
   composer install
   npm install
   ```
3. Copy file `.env.example` ke `.env`:
   ```bash
   cp .env.example .env
   ```
4. Generate application key:
   ```bash
   php artisan key:generate
   ```
5. Setup database di file `.env`:
   ```env
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=multilog
   DB_USERNAME=root
   DB_PASSWORD=
   ```
6. Run migrations dan seeders:
   ```bash
   php artisan migrate
   php artisan db:seed
   ```
7. Build assets:
   ```bash
   npm run build
   # atau untuk development:
   npm run dev
   ```
8. Jalankan server:
   ```bash
   php artisan serve
   ```
## 🔑 Akun Test
Setelah menjalankan seeder, akun berikut tersedia:
### Admin
- **Email**: `admin@example.com`
- **Password**: `password`
- **Akses**: Semua fitur sistem
### Manager
- **Email**: `manager@example.com`
- **Password**: `password`
- **Akses**: Management user, dashboard
### User
- **Email**: `user@example.com`
- **Password**: `password`
- **Akses**: Dashboard personal saja
## 🗄️ Struktur Database
### Tabel `roles`
```sql
- id (Primary Key)
- name (VARCHAR) - admin, manager, user
- description (TEXT) - Deskripsi role
- created_at, updated_at (TIMESTAMP)
```
### Tabel `users`
```sql
- id (Primary Key)
- role_id (Foreign Key → roles.id)
- name (VARCHAR) - Nama lengkap user
- email (VARCHAR, UNIQUE) - Email user
- email_verified_at (TIMESTAMP)
- password (VARCHAR) - Password yang di-hash
- first_name (VARCHAR) - Nama depan
- last_name (VARCHAR) - Nama belakang
- phone (VARCHAR) - Nomor telepon
- address (TEXT) - Alamat
- created_at, updated_at (TIMESTAMP)
```
## 🛡️ Penggunaan Middleware
Gunakan middleware `role` untuk membatasi akses berdasarkan role:
```php
// Routes hanya untuk admin
Route::middleware('role:admin')->group(function () {
    Route::get('/admin/settings', [SettingsController::class, 'index']);
});
// Routes untuk admin dan manager
Route::middleware('role:admin,manager')->group(function () {
    Route::resource('/admin/users', UserController::class);
});
// Routes untuk semua role yang terautentikasi
Route::middleware('role:admin,manager,user')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index']);
});
```
## 🔧 Helper Methods di User Model
```php
// Cek role
$user->hasRole('admin');        // Boolean: apakah user punya role tertentu
$user->isAdmin();              // Boolean: apakah user adalah admin
$user->isManager();            // Boolean: apakah user adalah manager  
$user->isUser();               // Boolean: apakah user adalah regular user
// Mendapatkan informasi role
$user->role->name;             // String: nama role
$user->role->description;      // String: deskripsi role
// Profile helpers
$user->getFullNameAttribute(); // String: nama lengkap (first_name + last_name)
```
## 🛣️ Routes
### Public Routes
- `GET /` - Redirect ke dashboard atau login
- `GET /login` - Halaman form login
- `POST /login` - Proses autentikasi login
- `POST /logout` - Logout dan redirect ke login
### Protected Routes (Authentication Required)
- `GET /dashboard` - Dashboard berdasarkan role user
### Admin Routes (Admin/Manager Only)
- `GET /admin/users` - List dan pencarian semua user
- `GET /admin/users/create` - Form tambah user baru
- `POST /admin/users` - Simpan user baru
- `GET /admin/users/{user}` - Detail informasi user
- `GET /admin/users/{user}/edit` - Form edit user
- `PUT /admin/users/{user}` - Update data user
- `DELETE /admin/users/{user}` - Hapus user
## 🎨 UI Components
Project ini menggunakan **Tailwind CSS v4** dengan komponen yang sudah dibuat:
- **Layout**: Responsive sidebar navigation
- **Forms**: Styled form inputs dengan validation
- **Tables**: Data tables dengan sorting dan pagination
- **Cards**: Dashboard cards dengan statistik
- **Buttons**: Various button styles dan states
- **Alerts**: Flash message components
- **Modals**: Confirmation dialogs
## 🔄 Pengembangan Lebih Lanjut
Fitur yang bisa ditambahkan:
### Security & Auth
- [ ] Permission system yang lebih granular
- [ ] Email verification untuk registrasi
- [ ] Password reset via email
- [ ] Two-factor authentication (2FA)
- [ ] Session management
### User Experience
- [ ] Profile management dengan upload foto
- [ ] Activity logging dan audit trail
- [ ] Notification system
- [ ] Advanced search dan filtering
- [ ] Export data (PDF, Excel)
### Advanced Features
- [ ] API dengan Sanctum/Passport
- [ ] Real-time notifications dengan Pusher
- [ ] Multi-tenant support
- [ ] Advanced reporting dashboard
- [ ] Integration dengan third-party services
## 🛠️ Technologies Used
- **Backend**: Laravel 11.x
- **Frontend**: Blade Templates + Alpine.js
- **CSS Framework**: Tailwind CSS v4
- **Database**: MySQL/PostgreSQL/SQLite
- **Build Tool**: Vite 7.x
- **Package Manager**: Composer + NPM
- **Authentication**: Laravel Built-in Auth
- **Validation**: Laravel Form Requests
- **Icons**: Heroicons
## 📁 Struktur Project
```
multilog/
├── app/
│   ├── Http/
│   │   ├── Controllers/     # Controllers untuk routes
│   │   └── Middleware/      # Custom middleware (RoleMiddleware)
│   └── Models/             # Eloquent models (User, Role)
├── database/
│   ├── migrations/         # Database migrations
│   └── seeders/           # Database seeders
├── resources/
│   ├── css/               # Tailwind CSS files
│   ├── js/                # JavaScript files
│   └── views/             # Blade templates
├── routes/
│   └── web.php            # Web routes definition
└── public/                # Public assets
```
## 🤝 Contributing
Kontribusi sangat diterima! Untuk berkontribusi:
1. Fork repository ini
2. Buat branch feature baru (`git checkout -b feature/AmazingFeature`)
3. Commit perubahan (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Buka Pull Request
## 📝 License
Proyek ini dibuat untuk keperluan pembelajaran dan dapat digunakan secara bebas.
## 🐛 Bug Reports & Feature Requests
Jika Anda menemukan bug atau ingin request fitur baru, silakan:
1. Cek dulu di [Issues](https://github.com/kanggawe/multilog/issues) apakah sudah ada yang serupa
2. Jika belum ada, buat issue baru dengan detail yang jelas
3. Sertakan steps to reproduce untuk bug reports
## 📞 Support
Jika Anda memiliki pertanyaan atau membutuhkan bantuan:
- Buka issue di GitHub repository
- Kirim email ke developer
---
**⭐ Jika project ini berguna untuk Anda, jangan lupa berikan star!**
**Dibuat dengan ❤️ menggunakan Laravel dan Tailwind CSS**
